
        /*****************************************************************************
         * 		BusinessMenuActivity                                                 *
         * 		COMP313.Section. 002                                                 *
         * 		Created by Team 5 on 17.04.2022                                      *
         * 		This file contains code implementation of the Business Menu Activity *
         *****************************************************************************/
package com.example.vac_check;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BusinessMenuActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_menu);

    }

    public void ScanQRCode(View view){
        Intent intent = new Intent(this, QRCodeScanner.class);
        startActivity(intent);
    }

    public void Logout(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }


}