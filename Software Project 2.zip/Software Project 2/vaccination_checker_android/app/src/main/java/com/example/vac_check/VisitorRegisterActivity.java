
        /***********************************************************************************
         * 		VisitorRegister  Activity                                                  *
         * 		COMP313.Section. 002                                                       *
         * 		Created by Team 5 on 17.04.2022                                            *
         * 		This file contains code implementation of the Visitor Registration Screen  *
         ***********************************************************************************/

package com.example.vac_check;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

public class VisitorRegisterActivity extends AppCompatActivity {
    private EditText fullNameET;
    private EditText emailET;
    private EditText VisitorContactNumberET;
    private EditText VisitorUserNameET;
    private EditText VisitorPasswordET;
    private Button VisitorRegister;
    private RadioButton YesButton;
    private RadioButton NoButton;
    private String token;
    private RadioGroup RadioGroupVac;

    public static final String EXTRA_MESSAGE = "qrCodeData";
    public static final String EXTRA_NAME = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitorregister);
        fullNameET = (EditText)findViewById(R.id.Name);
        emailET = (EditText)findViewById(R.id.Email);
        VisitorContactNumberET = (EditText)findViewById(R.id.ContactNumberv);
        VisitorUserNameET = (EditText)findViewById(R.id.VisitorUserName);
        VisitorPasswordET = (EditText)findViewById(R.id.VisitorPassword);
        VisitorRegister = (Button)findViewById(R.id.VisitorRegisterButton);
        YesButton = (RadioButton)findViewById(R.id.yesButton);
        NoButton = (RadioButton)findViewById(R.id.noButton);
        RadioGroupVac = (RadioGroup)findViewById(R.id.radioGroupVac);



        VisitorRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                String fName = fullNameET.getText().toString();
                String emailStr = emailET.getText().toString();
                String contactNumber = VisitorContactNumberET.getText().toString();
                String userName = VisitorUserNameET.getText().toString();
                String pswd = VisitorPasswordET.getText().toString();

                //Input field Validation
                boolean check = validateInput(fName,emailStr,contactNumber,userName,pswd);
               if(check==true) {


                    AndroidNetworking.post("https://classvaccheck.herokuapp.com/users/register")
                            .addBodyParameter("name", fName)
                            .addBodyParameter("phoneNumber", contactNumber)
                            .addBodyParameter("email", emailStr)
                            .addBodyParameter("username", userName)
                            .addBodyParameter("userType", "0")
                            .addBodyParameter("password", pswd)
                            .addBodyParameter("isVaccinated", String.valueOf((YesButton.isChecked() ? 1 : 0)))
                            .build()
                            .getAsJSONObject(new JSONObjectRequestListener() {

                                @Override
                                public void onResponse(JSONObject response) {

                                    try {
                                        token = (String) response.get("token");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                    String innerName = userName;
                                    MainMenuActivity.AUTH_TOKEN = token;
                                    MainMenuActivity.IS_VACCINATED = YesButton.isChecked();

                                    AndroidNetworking.post("https://classvaccheck.herokuapp.com/vaxx/create")
                                            .addHeaders("X-Auth-Token", MainMenuActivity.AUTH_TOKEN)
                                            .build().getAsJSONObject(new JSONObjectRequestListener() {
                                        @Override
                                        public void onResponse(JSONObject response) {

                                            String qrCodeData = null;
                                            try {
                                                qrCodeData = (String) response.get("qrCodeUrl");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                            Intent intent = new Intent(getApplicationContext(), SelfScreeningActivity.class);
                                            intent.putExtra(EXTRA_MESSAGE, qrCodeData);
                                            intent.putExtra(EXTRA_NAME, innerName);
                                            Toast.makeText(VisitorRegisterActivity.this, "User Registered Successfully!",
                                                    Toast.LENGTH_LONG).show();
                                            System.out.println("User successfully registered!");
                                            startActivity(intent);
                                        }

                                        @Override
                                        public void onError(ANError anError) {
                                            Toast.makeText(getApplicationContext(),"Sorry, " + anError.getErrorBody() , Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }

                                @Override
                                public void onError(ANError error) {
                                    Toast.makeText(getApplicationContext(),"Sorry, " + error.getErrorBody(), Toast.LENGTH_SHORT).show();
                                }
                            });
                }else{
                  Toast.makeText(getApplicationContext(),"Sorry! Information not valid",Toast.LENGTH_SHORT).show();
               }

            }
        });

    }
    public void OnCheckedChanged(RadioGroup group, int checkId){
        switch (checkId){
            case R.id.yesButton:
                Log.i( "onCheckedChanged","Yes");
                break;
            case R.id.noButton:
                Log.i("onCheckedChanged","No");
                break;
        }
    }
    //Validate input method
    private Boolean validateInput(String name, String email,String phoneNum, String userName, String password){
        if(name.length()==0){
            fullNameET.requestFocus();
            fullNameET.setError("THIS FIELD CANNOT BE EMPTY");
            return false;
        }else if(!name.matches("[a-zA-Z_ ]+")){
            fullNameET.requestFocus();
            fullNameET.setError("ENTER ONLY ALPHA CHARACTERS");
            return false;

        }else if(email.length()==0){
            emailET.requestFocus();
            emailET.setError("THIS FIELD CANNOT BE EMPTY");
            return false;//
        }else if(!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+")) {
            emailET.requestFocus();//$"
            emailET.setError("ENTER VALID EMAIL");
            return false;

        }else if(phoneNum.length()==0){
            VisitorContactNumberET.requestFocus();
            VisitorContactNumberET.setError("THIS FIELD CANNOT BE EMPTY");
            return false;
        }else if(userName.length()==0){
            VisitorUserNameET.requestFocus();
            VisitorUserNameET.setError("THIS FIELD CANNOT BE EMPTY");
            return false;
        }else if(!phoneNum.matches("^\\(?([0-9]{3})\\)?[-.\\\\s]?([0-9]{3})[-.\\\\s]?([0-9]{4})$")){
            VisitorContactNumberET.requestFocus();
            VisitorContactNumberET.setError("INCORRECT PHONE NUMBER FORMAT");
            return false;

            /*Correct format
            * 1234567890 :    true
              123-456-7890 :    true
              123.456.7890 :    true
              123 456 7890 :    true
              (123) 456 7890 :  true

              12345678 :      false
              12-12-111 :     false
            * */
        }else if(password.length()<=5){
            VisitorPasswordET.requestFocus();
            VisitorPasswordET.setError("MINIMUM PASSWORD LENGTH IS 5");
            return false;

        }else if(!YesButton.isChecked() && !NoButton.isChecked()) {
            Toast.makeText(getApplicationContext(),"Please provide your vaccination status",Toast.LENGTH_SHORT).show();
            return false;

        }else{
            return true;
        }

    }

}