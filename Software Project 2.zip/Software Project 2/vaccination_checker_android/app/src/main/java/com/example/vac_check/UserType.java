
        /*****************************************************************************
         * 		UserType                                                             *
         * 		COMP313.Section. 002                                                 *
         * 		Created by Team 5 on 17.04.2022                                      *
         * 		This file contains code implementation of the generic user classes   *
         * 		for our visitor and business user classes                            *
         *****************************************************************************/

package com.example.vac_check;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class UserType extends AppCompatActivity {
    private Button Visitor;
    private Button Business;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usertype);
        Visitor = (Button)findViewById(R.id.visitor);
        Visitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(view.getContext(), VisitorRegisterActivity.class);
                startActivity(intent);
            }
        });
        Business = (Button)findViewById(R.id.business);
        Business.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(view.getContext(), BusinessRegisterActivity.class);
                startActivity(intent);
            }
        });
    }

}
