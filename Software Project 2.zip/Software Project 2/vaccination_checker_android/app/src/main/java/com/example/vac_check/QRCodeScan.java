
        /******************************************************************************
         * 		QRCodeScan                                                            *
         * 		COMP313.Section. 002                                                  *
         * 		Created by Team 5 on 17.04.2022                                       *
         * 		This file contains code implementation of the QR Code Scan Activity   *
         ******************************************************************************/

package com.example.vac_check;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class QRCodeScan extends AppCompatActivity {
    Button scanbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_scan);
        scanbtn = (Button)findViewById(R.id.scanbtn);
        scanbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View view){
                Intent intent = new Intent(QRCodeScan.this,QRCodeScanner.class);
                startActivity(intent);

            }
        });
    }
}