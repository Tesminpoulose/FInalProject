const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('../models/User');

/* POST Login. */
router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Simple validation
    if(!username || !password) {
        return res.status(400).json({ msg: 'Please enter all fields' });
    }

    // Check if user exists
    const user = await User.findOne({username});
    console.log(user)
    if (user === null) {
        return res.status(400).json({ message: 'Wrong credentials.'});
    }

    // Check if password match
    const result = await bcrypt.compare(password, user.password);
    if (!result) {
        return res.status(400).json({ message: 'Wrong credentials.'});
    }
    
    //Create JWT for registered user
    const token = jwt.sign({id: user._id}, process.env.JWT_KEY, {expiresIn: 3600});
    return res.status(200).json({message: 'Logged In', token: token});
});

/* POST Register. */
router.post('/register', async (req, res) => {
    const { name, phoneNumber, email, username, userType, password, isVaccinated } = req.body;

    // Simple validations
    // Fields must be provided
    if(!name ||!phoneNumber || !email || !password || !username) {
        return res.status(400).json({ message: 'Please enter all fields.' });
    }

    if (userType == 0) {
    //Check for existing user
    let user = await User.findOne({ email });

    if (user != null) {
        return res.status(400).json({ message: 'This user already exists.'});
    }
}

    //Register new user
    const newUser = new User({
        name,
        phoneNumber,
        email,
        username,
        userType,
        password,
        isVaccinated
    });

    //Generate salt for password hashing
    const salt = await bcrypt.genSalt();
    //Hash the password
    newUser.password = await bcrypt.hash(newUser.password, salt);

    user = await newUser.save();
    //Create JWT for registered user
    const token = jwt.sign({id: user._id}, process.env.JWT_KEY, {expiresIn: 3600});
    return res.status(201).json({message: 'Registered', token: token});
});

module.exports = router;