const ensureAuthenticated = require('../middlewares/auth');
const express = require('express');
const router = express.Router();
const QRCode = require('qrcode')

const Vaxx = require('../models/Vaxx')
const User = require('../models/User')

const generateToken = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let token = '';
    for(let i = 0; i < 31; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}

/* POST vaxx passport. */
router.post('/create', ensureAuthenticated, async (req, res) => {
    const randToken = generateToken();
    const qrl = await QRCode.toDataURL(req.headers.host + '/vaxx/' + randToken);
    const date = new Date();

    const newPassport = new Vaxx({userId: req.user.id, token: randToken, expiryDate: date.setDate(date.getDate() + 1), qrCodeUrl: qrl});
    await newPassport.save();

    return res.json(newPassport);
});

/* POST vaxx passport update. */
router.post('/update/:token', ensureAuthenticated, async (req, res) => {
    const randToken = generateToken();
    const qrl = await QRCode.toDataURL(req.headers.host + '/vaxx/' + randToken);
    const date = new Date();
    const vaxx = await Vaxx.findOneAndUpdate(
        {token: req.params.token}, 
        {token: randToken, expiryDate: date.setDate(date.getDate() + 1), qrCodeUrl: qrl}, 
        {runValidators: true, useFindAndModify: true, new: true}
    );

    return res.json(vaxx);
});

/* GET vaxx passport. */
router.get('/:token', async (req, res) => {
    const vaxx = await Vaxx.find({token: req.params.token});

    if (vaxx[0] == null){
        return res.render('check', {vaxxStatus: 0, className: "danger"})[0];
    }

    const user = await User.find({userId: vaxx[0].userId})
    if (user[0].isVaccinated === true) {
        const vaxxResponse = res.render('check', {vaxxStatus: 1, className: "success", info: vaxx[0], user: user[0]})
    } else {
        const vaxxResponse = res.render('check', {vaxxStatus: 1, className: "danger", info: vaxx[0], user: user[0]})
    }
    console.log(vaxx)
    return vaxxResponse
});

module.exports = router;