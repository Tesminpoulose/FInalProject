const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', (req, res, next) => {
  return res.render('index', { title: 'Express' });
});

router.get('/check', (req, res, next) => {
  return res.render('check', { title: 'Check' });
});

module.exports = router;
