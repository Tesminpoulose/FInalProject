const mongoose = require('mongoose');

const CustomerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    surname: {
        type: String,
        required: true
    },
    number: {
        type: String,
        required: true
    },
    vacStatus: {
        type: Bool,
        default: false
    },
    qrCode: {
        type: String,
        required: true
    },
    qrCodeExpDate: {
        type: Date,
        default: Date.now
    }
});

const Customer = mongoose.model('Customer', CustomerSchema);

module.exports = Customer;