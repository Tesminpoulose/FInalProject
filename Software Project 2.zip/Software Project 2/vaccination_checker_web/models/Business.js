const mongoose = require('mongoose');

const BusinessSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    number: {
        type: String,
        required: true
    },
    maxOccupants: {
        type: String,
        required: true
    }
});

const business = mongoose.model('Business', BusinessSchema);

module.exports = business;