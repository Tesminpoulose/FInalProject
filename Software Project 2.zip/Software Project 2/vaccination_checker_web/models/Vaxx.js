const mongoose = require('mongoose');

const VaxxSchema = new mongoose.Schema({
    token: {
        type: String,
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'User'
    },
    qrCodeUrl: {
        type: String,
        required: true
    },
    expiryDate: {
        type: Date,
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    }
});

const Vaxx = mongoose.model('Vaxx', VaxxSchema);

module.exports = Vaxx;