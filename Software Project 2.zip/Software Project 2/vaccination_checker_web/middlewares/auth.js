const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.header('x-auth-token');

  // Check for token
  if (!token)
    return res.status(401).json({ msg: 'No token, authorizaton denied' });

  try {
    // Verify token and add user from payload
    req.user = jwt.verify(token, process.env.JWT_KEY);
    next();
  } catch (e) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};